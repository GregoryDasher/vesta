// muguet - patch.rs (Android-compatible)
// Constantin Clerc (c22dev) - 0.1

use anyhow::{bail, Context, Result};
use std::collections::HashMap;
use wasm_encoder::reencode::{utils, Error, Reencode};
use wasm_encoder::ValType::I64;
use wasmparser::{KnownCustom, Name, Parser, Payload, TypeRef};

/// Локальная реализация Jenkins one-at-a-time hash (joaat).
/// Раньше бралась из `crate::proto::joaat`, но proto отключён на Android.
fn joaat(s: &str) -> u32 {
    let mut h: u32 = 0;
    for b in s.bytes() {
        h = h.wrapping_add(b.to_ascii_lowercase() as u32);
        h = h.wrapping_add(h << 10);
        h ^= h >> 6;
    }
    h = h.wrapping_add(h << 3);
    h ^= h >> 11;
    h = h.wrapping_add(h << 15);
    h
}

#[derive(Clone, Copy, PartialEq)]
enum Arg {
    Local0,
    TlsBase,
    Local1Replaced,
    MissingText,
    TxdLoaded,
    PoolGrow,
    CashWrite,
    OpusFrame,
}

/// Хуки для мультиплеера нужны только на iOS.
/// На Android список пуст — game.wasm патчится только для одиночной игры
/// (scenario_check и movie_preload — единственное, что остаётся).
#[cfg(target_os = "ios")]
const HOOKS: &[(&str, &str, &[Arg])] = &[
    ("muguet_script", "GtaThread::Update(int)", &[Arg::Local0, Arg::TlsBase]),
    ("muguet_explosion", "CExplosionManager::AddExplosion(CExplosionManager::CExplosionArgs&, CProjectile*, bool)", &[Arg::Local0]),
    ("muguet_timewarp", "CTimeWarper::SetTargetTimeWarp(TW_Dir)", &[Arg::Local1Replaced]),
    ("muguet_text", "CTextFile::GetInternal(unsigned int)", &[Arg::MissingText]),
    ("muguet_txd", "graphics_commands::HasStreamedTxdLoaded(char const*)", &[Arg::TxdLoaded, Arg::TxdLoaded]),
    ("muguet_pool", "rage::sysMemGrowBuddyAllocator::GrowHeap()", &[Arg::PoolGrow]),
    ("muguet_cash", "stats_commands::CommandStatSetInt(int, int, bool)", &[Arg::CashWrite, Arg::CashWrite]),
    ("muguet_opus_frame", "opus_decode_frame", &[Arg::OpusFrame; 6]),
];

#[cfg(not(target_os = "ios"))]
const HOOKS: &[(&str, &str, &[Arg])] = &[];

const SCENARIO_CHECK: &str = "CScenarioManager::PerformCollisionChecksForScenarioPoint(CScenarioManager::CollisionCheckParams const&)";
const MOVIE_PRELOAD: &str = "CMovieMgr::PreloadMovie(char const*, bool)";

pub const VERSION: u32 = 10;

fn returns(args: &[Arg]) -> bool {
    args.contains(&Arg::Local1Replaced) || args.contains(&Arg::MissingText) || args.contains(&Arg::TxdLoaded) || args.contains(&Arg::PoolGrow) || args.contains(&Arg::CashWrite) || args.contains(&Arg::OpusFrame)
}

struct Patcher {
    imported_funcs: u32,
    types: u32,
    tls_global: u32,
    targets: HashMap<u32, usize>,
    scenario_check: Option<u32>,
    movie_preload: Option<u32>,
    pool_size: Option<u32>,
    exports: Vec<(String, u32)>,
    next_func: u32,
}

impl Patcher {
    fn shift(&self) -> u32 {
        HOOKS.len() as u32
    }
}

impl Reencode for Patcher {
    type Error = anyhow::Error;

    fn function_index(&mut self, f: u32) -> Result<u32, Error<Self::Error>> {
        Ok(if f >= self.imported_funcs { f + self.shift() } else { f })
    }

    fn parse_type_section(&mut self, types: &mut wasm_encoder::TypeSection, section: wasmparser::TypeSectionReader<'_>) -> Result<(), Error<Self::Error>> {
        utils::parse_type_section(self, types, section)?;
        for (_, _, args) in HOOKS {
            types.ty().function(vec![I64; args.len()], if returns(args) { vec![I64] } else { vec![] });
        }
        Ok(())
    }

    fn parse_import_section(&mut self, imports: &mut wasm_encoder::ImportSection, section: wasmparser::ImportSectionReader<'_>) -> Result<(), Error<Self::Error>> {
        utils::parse_import_section(self, imports, section)?;
        for (k, (name, _, _)) in HOOKS.iter().enumerate() {
            imports.import("env", name, wasm_encoder::EntityType::Function(self.types + k as u32));
        }
        Ok(())
    }

    fn parse_export_section(&mut self, exports: &mut wasm_encoder::ExportSection, section: wasmparser::ExportSectionReader<'_>) -> Result<(), Error<Self::Error>> {
        utils::parse_export_section(self, exports, section)?;
        for (name, f) in std::mem::take(&mut self.exports) {
            exports.export(&name, wasm_encoder::ExportKind::Func, f + self.shift());
        }
        Ok(())
    }

    fn parse_function_body(&mut self, code: &mut wasm_encoder::CodeSection, func: wasmparser::FunctionBody<'_>) -> Result<(), Error<Self::Error>> {
        let index = self.next_func;
        self.next_func += 1;
        if Some(index) == self.scenario_check {
            use wasm_encoder::Instruction as I;
            let mut f = self.new_function_with_parsed_locals(&func)?;
            let mut reader = func.get_operators_reader()?;
            while !reader.eof() {
                let i = self.parse_instruction(&mut reader)?;
                f.instruction(if matches!(i, I::I32Const(6)) { &I::I32Const(5) } else { &i });
            }
            code.function(&f);
            return Ok(());
        }
        if Some(index) == self.movie_preload {
            use wasm_encoder::Instruction as I;
            let mut f = self.new_function_with_parsed_locals(&func)?;
            f.instruction(&I::I32Const(0)).instruction(&I::Return);
            let mut reader = func.get_operators_reader()?;
            while !reader.eof() {
                f.instruction(&self.parse_instruction(&mut reader)?);
            }
            code.function(&f);
            return Ok(());
        }
        let Some(&hook) = self.targets.get(&index) else {
            return utils::parse_function_body(self, code, func);
        };
        let mut f = self.new_function_with_parsed_locals(&func)?;
        use wasm_encoder::Instruction as I;
        let call = I::Call(self.imported_funcs + hook as u32);
        if HOOKS[hook].2 == [Arg::PoolGrow] {
            let Some(size) = self.pool_size else { return Err(Error::UserError(anyhow::anyhow!("GetHeapSize not found"))) };
            f.instruction(&I::LocalGet(0)).instruction(&I::Call(size + self.shift())).instruction(&call).instruction(&I::I64Eqz);
            f.instruction(&I::If(wasm_encoder::BlockType::Empty));
            f.instruction(&I::I32Const(-1)).instruction(&I::Return);
            f.instruction(&I::End);
        } else if HOOKS[hook].2.contains(&Arg::OpusFrame) {
            for (k, wide) in [true, true, false, true, false, false].into_iter().enumerate() {
                f.instruction(&I::LocalGet(k as u32));
                if !wide { f.instruction(&I::I64ExtendI32S); }
            }
            f.instruction(&call).instruction(&I::I32WrapI64).instruction(&I::Return);
        } else if HOOKS[hook].2 == [Arg::MissingText] {
            // only call out for the listed hashes: text lookups are hot
            for (label, _) in crate::host::MISSING_TEXT {
                f.instruction(&I::LocalGet(0)).instruction(&I::I32Const(joaat(label) as i32)).instruction(&I::I32Eq);
                f.instruction(&I::If(wasm_encoder::BlockType::Empty));
                f.instruction(&I::LocalGet(0)).instruction(&I::I64ExtendI32U).instruction(&call).instruction(&I::Return);
                f.instruction(&I::End);
            }
        } else if HOOKS[hook].2.first() == Some(&Arg::CashWrite) {
            for k in 0..3 {
                f.instruction(&I::LocalGet(0)).instruction(&I::I32Const(joaat(&format!("SP{k}_TOTAL_CASH")) as i32)).instruction(&I::I32Eq);
                f.instruction(&I::If(wasm_encoder::BlockType::Empty));
                f.instruction(&I::LocalGet(1)).instruction(&I::I64ExtendI32S).instruction(&I::GlobalGet(self.tls_global)).instruction(&call).instruction(&I::I64Eqz).instruction(&I::I32Eqz);
                f.instruction(&I::If(wasm_encoder::BlockType::Empty)).instruction(&I::I32Const(1)).instruction(&I::Return).instruction(&I::End);
                f.instruction(&I::End);
            }
        } else if HOOKS[hook].2.first() == Some(&Arg::TxdLoaded) {
            f.instruction(&I::LocalGet(0)).instruction(&I::I64Const(0)).instruction(&call).instruction(&I::Drop);
            let mut reader = func.get_operators_reader()?;
            let mut last = None;
            while !reader.eof() {
                let i = self.parse_instruction(&mut reader)?;
                if let (I::Return, Some(I::LocalGet(2))) = (&i, &last) {
                    f.instruction(&I::Drop);
                    f.instruction(&I::I64Const(0)).instruction(&I::LocalGet(2)).instruction(&I::I64ExtendI32U).instruction(&I::I64Const(1)).instruction(&I::I64Add);
                    f.instruction(&call).instruction(&I::I32WrapI64);
                }
                f.instruction(&i);
                last = Some(i);
            }
            code.function(&f);
            return Ok(());
        } else {
            for arg in HOOKS[hook].2 {
                match arg {
                    Arg::Local0 => f.instruction(&I::LocalGet(0)),
                    Arg::TlsBase => f.instruction(&I::GlobalGet(self.tls_global)),
                    Arg::Local1Replaced => f.instruction(&I::LocalGet(1)).instruction(&I::I64ExtendI32U),
                    Arg::MissingText | Arg::TxdLoaded | Arg::PoolGrow | Arg::CashWrite | Arg::OpusFrame => unreachable!(),
                };
            }
            f.instruction(&call);
            if returns(HOOKS[hook].2) {
                f.instruction(&I::I32WrapI64);
                f.instruction(&I::LocalSet(1));
            }
        }
        let mut reader = func.get_operators_reader()?;
        while !reader.eof() {
            f.instruction(&self.parse_instruction(&mut reader)?);
        }
        code.function(&f);
        Ok(())
    }
}

pub fn is_patched(wasm: &[u8]) -> bool {
    let Some((first_name, _, _)) = HOOKS.first() else { return false; };
    Parser::new(0).parse_all(wasm).any(|p| match p {
        Ok(Payload::ImportSection(s)) => s.into_imports().any(|i| i.is_ok_and(|i| i.name == *first_name)),
        _ => false,
    })
}

pub fn patch(wasm: &[u8], wanted: &[(&str, &str)]) -> Result<Vec<u8>> {
    let (mut imported_funcs, mut types, mut tls_global) = (0u32, 0u32, None);
    let mut by_name: HashMap<String, u32> = HashMap::new();
    for payload in Parser::new(0).parse_all(wasm) {
        match payload? {
            Payload::TypeSection(s) => types = s.count(),
            Payload::ImportSection(s) => {
                for imp in s.into_imports() {
                    if matches!(imp?.ty, TypeRef::Func(_)) {
                        imported_funcs += 1;
                    }
                }
            }
            Payload::CustomSection(c) => {
                if let KnownCustom::Name(names) = c.as_known() {
                    for sub in names {
                        match sub? {
                            Name::Function(map) => {
                                for n in map {
                                    let n = n?;
                                    by_name.entry(n.name.to_string()).or_insert(n.index);
                                }
                            }
                            Name::Global(map) => {
                                for n in map {
                                    let n = n?;
                                    if n.name == "__tls_base" { tls_global = Some(n.index); }
                                }
                            }
                            _ => {}
                        }
                    }
                }
            }
            _ => {}
        }
    }
    if let Some((first_name, _, _)) = HOOKS.first() {
        if by_name.contains_key(*first_name) {
            bail!("game.wasm is already patched");
        }
    }
    let mut targets = HashMap::new();
    for (k, (_, func, _)) in HOOKS.iter().enumerate() {
        let f = *by_name.get(*func).with_context(|| format!("{func} not found (no name section?)"))?;
        targets.insert(f, k);
    }
    let mut exports = Vec::new();
    if let Some(&malloc) = by_name.get("emscripten_builtin_malloc") {
        exports.push(("muguet:malloc".to_string(), malloc));
    }
    for (export, func) in wanted {
        match by_name.get(*func) {
            Some(&i) => exports.push((format!("mp:{export}"), i)),
            None => eprintln!("[patch] {func} not found; multiplayer will skip it"),
        }
    }
    let mut p = Patcher {
        imported_funcs,
        types,
        tls_global: tls_global.unwrap_or(1),
        targets,
        scenario_check: by_name.get(SCENARIO_CHECK).copied(),
        movie_preload: by_name.get(MOVIE_PRELOAD).copied(),
        pool_size: by_name.get("rage::sysMemGrowBuddyAllocator::GetHeapSize() const").copied(),
        exports,
        next_func: imported_funcs,
    };
    let mut module = wasm_encoder::Module::new();
    p.parse_core_module(&mut module, Parser::new(0), wasm).map_err(|e| anyhow::anyhow!("patch game.wasm: {e:?}"))?;
    Ok(module.finish())
}